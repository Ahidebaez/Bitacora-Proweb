// creating an array and passing the number, questions, options, and answers
let questions = [
  {
    numb: 1,
    question: "¿Qué significa HTML?",
    answer: "Lenguaje de Marcado de Hipertexto",
    options: [
      "Procesador de Hipertexto",
      "Lenguaje de Marcado de Hipertexto",
      "Lenguaje de Hipertexto Múltiple",
      "Herramienta de Hipertexto Multilingüe"
    ]
  },
  {
    numb: 2,
    question: "¿Qué significa CSS?",
    answer: "Hoja de Estilos en Cascada",
    options: [
      "Hoja de Estilos Común",
      "Hoja de Estilos Colorida",
      "Hoja de Estilos para Computadora",
      "Hoja de Estilos en Cascada"
    ]
  },
  {
    numb: 3,
    question: "¿Qué significa PHP?",
    answer: "Preprocesador de Hipertexto",
    options: [
      "Preprocesador de Hipertexto",
      "Programación de Hipertexto",
      "Preprogramación de Hipertexto",
      "Preprocesador de Texto Doméstico"
    ]
  },
  {
    numb: 4,
    question: "¿Qué significa SQL?",
    answer: "Lenguaje de Consulta Estructurado",
    options: [
      "Lenguaje de Pregunta Elegante",
      "Lenguaje de Consulta de Hoja de Estilo",
      "Lenguaje de Pregunta de Declaración",
      "Lenguaje de Consulta Estructurado"
    ]
  },
  {
    numb: 5,
    question: "¿Qué significa XML?",
    answer: "Lenguaje de Marcado Extensible",
    options: [
      "Lenguaje de Marcado Extensible",
      "Lenguaje de Múltiples Ejecuciones",
      "Lenguaje de Programación Multifuncional Adicional",
      "Lenguaje de Múltiples Examenes"
    ]
  }
];

  
;